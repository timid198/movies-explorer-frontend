import React from 'react';
import './Promo.css';

function Promo() {
    return (
        <div className="promo">
            <h1 className="promo-title">Учебный проект студента факультета Веб-разработки.</h1>
        </div>
    )
}

export default Promo;